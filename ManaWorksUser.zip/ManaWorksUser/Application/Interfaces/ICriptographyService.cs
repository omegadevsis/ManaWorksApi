namespace ManaWorksUser.Application.Interfaces;

public interface ICriptographyService
{
    string EncryptString(string plainText);
}