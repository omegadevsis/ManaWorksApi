namespace ManaWorksUser.Infrastructure.Security;

public class Settings
{
    public static string Secret = "kO+aMfTbJ3z42/Ugfpwq+ShshZoOcUjPjDfP1XQ0jxQ=";
}